
# include <iostream>
# include "app_window.h"
# include <vector>
# include "Vec.h"
# include "Rect.h"
using namespace std;
AppWindow::AppWindow ( const char* label, int x, int y, int w, int h )
          :GlutWindow ( label, x, y, w, h )
{
   _markx = 0;
   _marky = 0;
   addMenuEntry ( "Option 0", evOption0 );
   addMenuEntry ( "Option 1", evOption1 );
	stash.push_back(new Rect(-0.6,0.7, 0.8, 0.6, 1.0, 0.0, 0.0));
	stash.push_back(new Rect(-0.6,-0.2, 0.8, 0.6, 0.0, 0.0, 1.0));
	stash.push_back(new Rect(0.1,0.7, 0.8, 0.6, 0.0, 1.0, 0.0));
	xoff=0;
	yoff=0;
	mouseDown=false;
	drag = false;
}

// so make here the conversion when needed
void AppWindow::windowToScene ( float& x, float &y )
 {
   x = (2.0f*(x/float(_w))) - 1.0f;
   y = 1.0f - (2.0f*(y/float(_h)));
 }

// Called every time there is a window event
void AppWindow::handle ( const Event& e )
 {
   bool rd=true;

   if ( e.type==Keyboard ) 
    switch ( e.key )
    { case ' ': // space bar
	std::cout << "Space pressed.\n";
	//1.5 for both originally
       _markx = 0.0;
       _marky = 0.0;
       redraw();
	   break;

	  case 27: // Esc was pressed
	   exit(1);
	}
   if ( e.type==MouseDown || e.type==Motion)
    { 
	_markx=(float)e.mx;
	_marky=(float)e.my;
	windowToScene(_markx,_marky);
	Vec position = Vec(_markx,_marky);
    }
	if(!mouseDown){
		Vec position = Vec(_markx, _marky);
		for(vector<Rect*>::iterator i =stash.begin(); i!=stash.end();i++){
			(*i)->deselect();
		}
		for(vector<Rect*>::iterator i = stash.begin(); i!=stash.end();i++){
			if((*i)->contains(position)){
				(*i)->select();
				drag = true;
				xoff = _markx-(*i)->getX();
				yoff = _marky-(*i)->getY();
				Rect* temp = *i;
				stash.erase(i);
				stash.insert(stash.begin(), temp);
				break;
			}
		}	
	
	}
	mouseDown = true;
	if(drag){
		Rect * top = stash[0];
		top->setX(_markx - xoff);
		top->setY(_marky - yoff);
	}
	if(e.type == MouseUp){
		mouseDown = false;
		drag = false;
	}


   if ( e.type==Menu )
    { std::cout<<"Menu Event: "<<e.menuev<<std::endl;
      rd=false; // no need to redraw
    }

   const float incx=0.02f;
   const float incy=0.02f;
   if ( e.type==SpecialKey )
    switch ( e.key )
    { case GLUT_KEY_LEFT:  _markx-=incx; break;
      case GLUT_KEY_RIGHT: _markx+=incx; break;
      case GLUT_KEY_UP:    _marky+=incy; break;
      case GLUT_KEY_DOWN:  _marky-=incy; break;
      default: rd=false; // no redraw
	}

   if (rd) redraw(); // ask the window to be rendered when possible
}

void AppWindow::resize ( int w, int h )
 {
   // Define that OpenGL should use the whole window for rendering
   glViewport( 0, 0, w, h );
   _w=w; _h=h;
 }

// here we will redraw the scene according to the current state of the application.
void AppWindow::draw ()
 {
   // Clear the rendering window
   glClear ( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );

   // Clear the trasnformation stack
   glMatrixMode( GL_MODELVIEW );
   glLoadIdentity();


   // you may use GL_POLYGON for generic *convex* polygons, like this:
	for(vector<Rect*>::iterator i = stash.begin(); i != stash.end(); i++){
		Vec t_left, t_right, b_right, b_left;
		Rect* curr = *i;
		//Set a setter/getter function in Vec call getX(), etc...
		t_left = Vec(curr->getX(), curr->getY());
		t_right = Vec(curr->getX() + curr->getW() , curr->getY());
		b_left = Vec(curr->getX(), curr->getY() - curr->getH());
		b_right = Vec(curr->getX()+curr->getW(), curr->getY()- curr->getH());

		float r, g, b;
		//Make getter and setters for rgb
		r = curr->getR();
		g = curr->getG();
		b = curr->getB();

		glColor3f(r,g,b);

   		glBegin(GL_POLYGON);

		glVertex2f(t_left.getX(),t_left.getY());
		glVertex2f(t_right.getX(),t_right.getY());
		glVertex2f(b_right.getX(),b_right.getY());
		glVertex2f(b_left.getX(),b_left.getY());
		glEnd();
	//While you're holding the rect object 
		if(curr->selected()){
			glColor3f(1.0,1.0,1.0);
			glBegin(GL_LINES);
			glVertex2d(t_left.getX(),t_left.getY());
			glVertex2d(t_right.getX(),t_right.getY());

			glVertex2d(t_right.getX(),t_right.getY());
			glVertex2d(b_right.getX(),b_right.getY());

			glVertex2d(b_right.getX(),b_right.getY());
			glVertex2d(b_left.getX(),b_left.getY());
	
			glVertex2d(b_left.getX(),b_left.getY());
			glVertex2d(t_left.getX(),t_left.getY());
			glEnd();
		}
	}
   // Swap buffers
   glFlush();         // flush the pipeline (usually not necessary)
   glutSwapBuffers(); // we were drawing to the back buffer, now bring it to the front
}
