#ifndef Rect_h
#define Rect_h
#include "Vec.h"
#include <iostream>
class Rect{
	public:
		float x, y, w, h, r, g ,b;
		bool sel;
		Rect(float x, float y, float w, float h){
			this->x=x;
			this->y=y;
			this->w=w;
			this->h=h;
			r=1.0;
			g=1.0;
			b=1.0;
			sel = false;
		}
		Rect(float x, float y, float w, float h, float r, float g, float b){
			this->x = x;
			this->y = y;
			this->w = w;
			this->h = h;
			this->r = r;
			this->g = g;
			this->b = b;
			sel = false;
		}
		void setX(float x){
			this->x = x;
		}
		void setY(float y){
			this->y = y;
		}
		void setH(float h){
			this->h = h;
		}
		void setW(float w){
			this->w = w;
		}
		float getX(){
			return x;
		}
		float getY(){
			return y;
		}
		float getW(){
			return w;
		}
		float getH(){
			return h;
		}
		float getR(){
			return r;
		}
		float getG(){
			return g;
		}
		float getB(){
			return b;
		}
		void select(){
			//Have to set to false since you haven't selected any of the rectangles
			sel = true;
		}
		void deselect(){
			sel = false;
		}
		bool selected(){
			return sel;
		}
		bool contains(Vec n){
			if((n.x > x && n.x < x+w) && (n.y > y-h && n.y < y)){
				return true;
			}
			else
				return false;
		}

};
#endif
