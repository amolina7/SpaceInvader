#ifndef RECT_H
#define RECT_H
#include <iostream>
#include "Vec.h"

using namespace std;

class GrRect {

	float x, y;
	float w, h;
	float r, g, b;

public:

	bool sel;

	GrRect() {
		x = 0.0;
		y = 0.0;
		w = 0.0;
		h = 0.0;
		r = 1.0;
		g = 1.0;
		b = 1.0;
		sel = false;
	}

	GrRect(float x, float y, float w, float h){
		this->x = x;
		this->y = y;
		this->w = w;
		this->h = h;
		r = 1.0;
		g = 1.0;
		b = 1.0;
		sel = false;
	}

	GrRect(float x, float y, float w, float h, float r, float g, float b) {
		this->x = x;
		this->h = h;
		this->r = r;
		this->g = g;
		this->b = b;
		sel = false;
	}

	float getX() const {
		return x;
	}

	float getY() const {
		return y;
	}

	float getW() const {
		return w;
	}

	float getH() const {
		return h;
	}

	float getR() const {
		return r;
	}

	float getG() const {
		return g;
	}

	float getB() const {
		return b;
	}

	void select() {
		sel = true;
	}

	void deselect() {
		sel = false;
	}

	bool selected() {
		return sel;
	}
	
	void setX(float x){
	this->x = x;
	}
	void setY(float y){
		this->y = y;
	}
	
	bool contains(Vec v) {
		if (((v.x > x) && (v.x < (x + w))) && ((v.y >(y - h)) && (v.y < y)))
			return true;
		else
			return false;
	}

};
#endif
