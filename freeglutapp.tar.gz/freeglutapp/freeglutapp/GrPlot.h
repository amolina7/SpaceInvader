#include "Rect.h"
#include <ctime>
class GrPlot : public Rect{
	public:
		float s, m;
		void get(){
			std::time_t t = std::time(NULL);
			std::tm* tm = std::localtime(&t);
			s = tm->tm_sec;
			m = tm->tm_min;
		}
		virtual void keyDraw(float k){
		
		}
		virtual void update(){

		}
};

class Player : public GrPlot{
	public:
		Player(float x, float y, float w, float h, float r, float g, float b){
			this->x = x;
			this->y = y;
			this->w = w;
			this->h = h;
			this->r = r;
			this->g = g;
			this->b = b;
		}
		virtual void draw(){
			Vec tl, tr, br, bl;
			tl = Vec(x, y);
			tr = Vec(x+w, y);
			br = Vec(x+w, y-h);
			bl = Vec(x, y-h);

			glColor3f(0.0,0.0,1.0);
			glBegin(GL_POLYGON);
			glVertex2f(tl.getX(),tl.getY());
			glVertex2f(tr.getX(),tr.getY());
			glVertex2f(tr.getX(), tr.getY()-0.1);
			glVertex2f(tl.getX(), tl.getY()-0.1);
			glEnd();

			glColor3f(r, g, b);
			glBegin(GL_POLYGON);
			glVertex2f(tl.getX(),tl.getY());
			glVertex2f(tr.getX(),tr.getY());
			glVertex2f(br.getX(),br.getY());
			glVertex2f(bl.getX(),bl.getY());
			glEnd();
		}

		void keyDraw(float x){
			if(x == 1.0){
				this->x = 1.0;
			}
			else if(x == -1.0){
				this->x = -1.0;
			}
			else{
				this->x = x - 0.05;
				std::cout << "New x = " << x << std::endl;
			}
		}

};

class Enemy : public GrPlot{
	public:
		//Maybe make a static variable that will increment x and y value
		//It will be static so the lifetime is based on the duration of the game rather than the function call
//		static int update_x;
		Enemy(float x, float y, float w, float h, float r, float g, float b){
			this->x = x;
			this->y = y;
			this->w = w;
			this->h = h;
			this->r = r;
			this->g = g;
			this->b = b;
		}
			
		virtual void draw(){
			Vec tl, tr, br, bl;
			tl = Vec(x, y);
			tr = Vec(x+w, y);
			br = Vec(x+w, y-h);
			bl = Vec(x, y-h);
			
			get();
			update();

			glColor3f(0.0,0.0,1.0);
			glBegin(GL_POLYGON);
			glVertex2f(tl.getX(),tl.getY());
			glVertex2f(tr.getX(),tr.getY());
			glVertex2f(tr.getX(), tr.getY()-0.1);
			glVertex2f(tl.getX(), tl.getY()-0.1);
			glEnd();

			glColor3f(r, g, b);
			glBegin(GL_POLYGON);
			glVertex2f(tl.getX(),tl.getY());
			glVertex2f(tr.getX(),tr.getY());
			glVertex2f(br.getX(),br.getY());
			glVertex2f(bl.getX(),bl.getY());
			glEnd();
		}
		void update(){
				static double s_counter;
				static double x_Position;
				std::cout << "Counter outside of scope: " << s_counter << std::endl;
	//			std::cout << "x_Position: " << x_Position << std::endl;
				std::cout << "x: " << x << std::endl;
				std::cout << "s: " << s << std::endl;
				std::cout << "s_counter: " << s_counter << std::endl;
	//			if(s_counter <= 5){
				if(x <= -0.1){	
				//	x = 0;
					x = x - 0.006;
	//				x_Position = x_Position - (0.01 * s);
					s_counter = s_counter + (0.01 * s);
					std::cout << "Plus" << std::endl;
					std::cout << "Counter(+): " << s_counter <<  std::endl;
	//				std::cout << "x_Position(++): " << x_Position << std::endl;
	//				x_Position = x;
					if(s_counter >= 5){
						y = 0;
						y = y - (0.01 * s);
						std::cout << "y(+): " << y << std::endl;
						if(y <= -1){
							std::cout << "Rekt" << std::endl;
					//		exit(1);
						}
					}
				}
				else{
				
	//			else if(s_counter > 5 && s_counter < 10){
	//				x = 0;
					x = x + 0.006;
	//				x_Position = x_Position + (0.01 * s);
	//				std::cout << "x_Position(+): " << x_Position << std::endl;
	//				x_Position = x + (0.02 * s);
					s_counter = s_counter + (0.01 * s);
					std::cout << "Negative" << std::endl;
					std::cout << "Counter(-): " << s_counter <<  std::endl;
					if(s_counter >= 9){
						y = 0;
						y = y - (0.01 * s);
						std::cout << "y(-): " << y << std::endl;
						if(y <= -1){
							std::cout << "Rekt" << std::endl;
					//		exit(1);
						}
					}
				}
/*
				else{
					//Reset
					s_counter = 0;
					std::cout << "Reset" << std::endl;
				}
*/
		}	

};
