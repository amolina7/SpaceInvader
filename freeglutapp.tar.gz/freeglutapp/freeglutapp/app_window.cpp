# include <iostream>
# include "app_window.h"
using namespace std;
AppWindow::AppWindow(const char* label, int x, int y, int w, int h)
	:GlutWindow(label, x, y, w, h)
{
	_markx = 0;
	_marky = 0;
	addMenuEntry("Option 0", evOption0);
	addMenuEntry("Option 1", evOption1);

	GrPlot* p  = new Player(0.0, -0.9, 0.1, 0.1, 0.0, 1.0, 0.0);
	stash.push_back(p);
	//	cout << i << endl;
	GrPlot* enemy = new Enemy(0.0, 0.0, 0.1, 0.1, 0.0, 0.0, 1.0);
	stash.push_back(enemy);
		
//	GrPlot* enemy = new Enemy(0.0, 0.0, 0.1, 0.1, 1.0, 0.0, 0.0);
	//Maybe create a new vector where you will store the different types of enemies
//	stash.push_back(enemy);
	xOffset = 0.0;
	yOffset = 0.0;
	mouseDown = false;
}

// mouse events are in window coordinates, but your scene is in [0,1]x[0,1],
// so make here the conversion when needed
void AppWindow::windowToScene(float& x, float &y)
{
	x = (2.0f*(x / float(_w))) - 1.0f;
	y = 1.0f - (2.0f*(y / float(_h)));
}

// Called every time there is a window event
void AppWindow::handle(const Event& e)
{
	bool rd = true;

	if (e.type == Keyboard)
		switch (e.key)
		{
		case ' ': // space bar
			std::cout << "Space pressed.\n";
			_markx = 1.5;
			_marky = 1.5;
			redraw();
			break;

		case 27: // Esc was pressed
			exit(1);
		}
	// mouse 
	if (e.type == MouseDown || e.type == Motion)
	{
		_markx = (float)e.mx;
		_marky = (float)e.my;
		windowToScene(_markx, _marky);
		Vec mousePos = Vec(_markx, _marky); 


	}

	if (e.type == MouseUp) {
		mouseDown = false;
	}

	if (e.type == Menu)
	{
		cout << "Menu Event: " << e.menuev << endl;
		rd = false; // no need to redraw
	}

	const float incx = 0.05;
	const float incy = 0.05;
	if (e.type == SpecialKey)
		switch (e.key)
		{
		case GLUT_KEY_LEFT:  _markx -= incx; if(_markx < -1.0) { _markx = -1.0; }std::cout << _markx << std::endl; stash[0]->keyDraw(_markx); break;
		case GLUT_KEY_RIGHT: _markx += incx; if(_markx > 0.9) { _markx = 0.9; }std::cout << _markx << std::endl; stash[0]->keyDraw(_markx); break;
		case GLUT_KEY_UP:    _marky += incy; break;
		case GLUT_KEY_DOWN:  _marky -= incy; break;
		default: rd = false; // no redraw
		}

	if (rd) redraw(); // ask the window to be rendered when possible
}

void AppWindow::resize(int w, int h)
{
	// Define that OpenGL should use the whole window for rendering
	glViewport(0, 0, w, h);
	_w = w; _h = h;
}

// here we will redraw the scene according to the current state of the application.
void AppWindow::draw()
{
	// Clear the rendering window
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// Clear the trasnformation stack
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	for (vector<GrPlot*>::iterator i = stash.begin(); i != stash.end(); ++i) {
			(*i)->draw();
		//	cout << (*i)->x << endl;
	}


	// Swap buffers
	glFlush();         // flush the pipeline (usually not necessary)
	glutSwapBuffers(); // we were drawing to the back buffer, now bring it to the front
}
