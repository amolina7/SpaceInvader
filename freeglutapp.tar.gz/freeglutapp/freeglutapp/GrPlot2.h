#include "Rect.h"

class GrPlot : public Rect{
	public:
		float x, y;
		std::vector<Vec> V;
		void add(float x, float y){
			Vec point(x,y);
			V.push_back(point);
		}				
		virtual void generate(float xini, float xend, float inc){
			
		}
};

class GrPlotQuadratic : public GrPlot{
	public:
		float a, b, c, r, g, blue; 
		
		GrPlotQuadratic(float a, float b, float c, float r, float g, float blue){
			this->a = a;
			this->b = b;
			this->c = c;
			this->r = r;
			this->g = g;
			this->blue = blue;
		}
		void generate(float xini, float xend, float inc){
			for(float i = xini; i <= xend; i+=inc){
				add(i, (a*i*i) + (b*i) + c);
			}
		}
		virtual void draw(){
			Vec tl, tr, br, bl;
			tl = Vec(x, y);
			tr = Vec(x+w, y);
			br = Vec(x+w, y-h);
			bl = Vec(x, y-h);
		
			glColor3f(0.0,0.0,0.0);
			glBegin(GL_LINES);
			glVertex2f(tl.getX(), tl.getY()-0.1);
			glVertex2f(tr.getX(), tr.getY()-0.1);
			glEnd();

			glBegin(GL_POINTS);
			for(std::vector<Vec*>::iterator i = points.begin(); i != points.end(); i++){
				glVertex2f(x + (*i)->getX(), y - (*i)->getY());
			}
			glEnd();

			glColor3f(r, g, b);
   			glBegin(GL_POLYGON);
			glVertex2f(tl.getX(),tl.getY());
			glVertex2f(tr.getX(),tr.getY());
			generate(0.1,0.9,0.01);
			glColor3f(1.0,1.0,1.0);
			glBegin(GL_POINTS);
			for(int i = 0; i < V.size(); i++){
				glVertex2f(V[i].x, V[i].y);
			}
			glEnd();
			glVertex2f(br.getX(),br.getY());
			glVertex2f(bl.getX(),bl.getY());
			glEnd();


		//While you're holding the rect object 

			if(sel){
				glColor3f(1.0,1.0,1.0);
				glBegin(GL_LINES);
				glVertex2d(tl.getX(),tl.getY());
				glVertex2d(tr.getX(),tr.getY());
		
				glVertex2d(tr.getX(),tr.getY());
				glVertex2d(br.getX(),br.getY());

				glVertex2d(br.getX(),br.getY());
				glVertex2d(bl.getX(),bl.getY());
		
				glVertex2d(bl.getX(),bl.getY());
				glVertex2d(tl.getX(),tl.getY());
				glEnd();
			}
	
		}
/*
		virtual void draw(){
			//Use generate
			//Draw the rectangles

			Rect* re = new Rect(-0.6, 0.7, 0.8, 0.6, 1.0, 0.0, 0.0);
			re->draw();

			generate(0.1,0.9,0.01);
			glColor3f(1.0,1.0,1.0);
			glBegin(GL_POINTS);
			for(int i = 0; i < V.size(); i++){
				glVertex2f(V[i].x, V[i].y);
			}
			glEnd();
	}
*/
};



class GrPlotCubic : public GrPlot{
	public:
		float a, b, c, d, r, g, blue, xini, xend, inc;
		
		GrPlotCubic(float a, float b, float c, float d, float r, float g, float blue){
			this->a = a;
			this->b = b;
			this->c = c;
			this->d = d;
			this->r = r;
			this->g = g;
			this->blue = blue;
		}
		void generate(float xini, float xend, float inc){
			for(float i = xini; i <= xend; i+=inc){
				add(i, (a*i*i*i) + (b*i*i) + (c*i) + d);
			}
		}
		virtual void draw(){
			Vec tl, tr, br, bl;
			tl = Vec(x, y);
			tr = Vec(x+w, y);
			br = Vec(x+w, y-h);
			bl = Vec(x, y-h);
		
			glColor3f(0.0,0.0,0.0);
			glBegin(GL_LINES);
			glVertex2f(tl.getX(), tl.getY()-0.1);
			glVertex2f(tr.getX(), tr.getY()-0.1);
			glEnd();

			glBegin(GL_POINTS);
			for(std::vector<Vec*>::iterator i = points.begin(); i != points.end(); i++){
				glVertex2f(x + (*i)->getX(), y - (*i)->getY());
			}
			glEnd();

			glColor3f(r, g, b);
   			glBegin(GL_POLYGON);
			glVertex2f(tl.getX(),tl.getY());
			glVertex2f(tr.getX(),tr.getY());
			glVertex2f(br.getX(),br.getY());
			glVertex2f(bl.getX(),bl.getY());
			glEnd();


		//While you're holding the rect object 

			if(sel){
				glColor3f(1.0,1.0,1.0);
				glBegin(GL_LINES);
				glVertex2d(tl.getX(),tl.getY());
				glVertex2d(tr.getX(),tr.getY());
		
				glVertex2d(tr.getX(),tr.getY());
				glVertex2d(br.getX(),br.getY());

				glVertex2d(br.getX(),br.getY());
				glVertex2d(bl.getX(),bl.getY());
		
				glVertex2d(bl.getX(),bl.getY());
				glVertex2d(tl.getX(),tl.getY());
				glEnd();
			}
	
		}
/*
		virtual void draw(){
			Rect* re = new Rect(-0.6, 0.7, 0.8, 0.6, 1.0, 0.0, 0.0);
			re->draw();
			
			generate(0.1,0.9,0.01);
			glColor3f(0.0,0.0,1.0);
			glBegin(GL_POINTS);
			for(int i = 0; i < V.size(); i++){
				glVertex2f(V[i].x, V[i].y);
			}
			glEnd();
		}
*/
};


