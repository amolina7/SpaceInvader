#ifndef Vec_h
#define Vec_h
class Vec{
	
	public:
		float x;
		float y;
		float w;
		float h;
		static Vec null;
		Vec(){
			x = 0.0; y = 0.0;
		}
		Vec(float x_coor, float y_coor){
			x = x_coor;
			y = y_coor;
		}
		Vec(float x_coor, float y_coor, float w, float h){
			x = x_coor;
			y = y_coor;
			this->h = h;
			this->w = w;
		}
		void add(Vec u){
			x = x + u.x;
			y = y + u.y;
		}
		void print(){
		//	std::cout<<"(" << x << ", " << y << ")";
		}
		float getX(){
			return x;
		}
		float getY(){
			return y;
		}
		float getW(){
			return w;
		}
		float getH(){
			return h;
		}
};
	
#endif
