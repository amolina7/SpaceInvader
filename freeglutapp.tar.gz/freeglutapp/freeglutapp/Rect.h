#ifndef RECT_H
#define RECT_H
#include <iostream>
#include "Vec.h"
#include "glut_window.h"
#include <vector>

class Rect {
public:
	float x, y, w, h;
	float r, g, b;
	std::vector< Vec* > points;

	bool sel;

	Rect() {
		x = 0.0;
		y = 0.0;
		w = 0.0;
		h = 0.0;
		r = 1.0;
		g = 1.0;
		b = 1.0;
		sel = false;
	}

	Rect(float x, float y, float w, float h){
		this->x = x;
		this->y = y;
		this->w = w;
		this->h = h;
		r = 1.0;
		g = 1.0;
		b = 1.0;
		sel = false;
	}

	Rect(float x, float y, float w, float h, float r, float g, float b) {
		this->x = x;
		this->y = y;
		this->w = w;
		this->h = h;
		this->r = r;
		this->g = g;
		this->b = b;
		sel = false;
	}

	float getX() const{
		return x;
	}

	float getY() const{
		return y;
	}

	float getW() const{
		return w;
	}

	float getH() const{
		return h;
	}

	float getR() const{
		return r;
	}

	float getG() const{
		return g;
	}

	float getB() const{
		return b;
	}

	void select() {
		sel = true;
	}

	void deselect() {
		sel = false;
	}

	bool selected() {
		return sel;
	}
	
	void setX(float x){
		this->x = x;
	}
	void setY(float y){
		this->y = y;
	}
	
	bool contains(Vec v) {
		if (((v.x > x) && (v.x < (x + w))) && ((v.y >(y - h)) && (v.y < y)))
			return true;
		else
			return false;
	}
	virtual void draw(){

		Vec tl, tr, br, bl;
		tl = Vec(x, y);
		tr = Vec(x+w, y);
		br = Vec(x+w, y-h);
		bl = Vec(x, y-h);
		
		glColor3f(0.0,0.0,0.0);
		glBegin(GL_LINES);
		glVertex2f(tl.getX(), tl.getY()-0.1);
		glVertex2f(tr.getX(), tr.getY()-0.1);
		glEnd();

		glBegin(GL_POINTS);
		for(std::vector<Vec*>::iterator i = points.begin(); i != points.end(); i++){
			glVertex2f(x + (*i)->getX(), y - (*i)->getY());
		}
		glEnd();

		glColor3f(r, g, b);
   		glBegin(GL_POLYGON);
		glVertex2f(tl.getX(),tl.getY());
		glVertex2f(tr.getX(),tr.getY());
		glVertex2f(br.getX(),br.getY());
		glVertex2f(bl.getX(),bl.getY());
		glEnd();


		//While you're holding the rect object 

		if(sel){
			glColor3f(1.0,1.0,1.0);
			glBegin(GL_LINES);
			glVertex2d(tl.getX(),tl.getY());
			glVertex2d(tr.getX(),tr.getY());
		
			glVertex2d(tr.getX(),tr.getY());
			glVertex2d(br.getX(),br.getY());

			glVertex2d(br.getX(),br.getY());
			glVertex2d(bl.getX(),bl.getY());
		
			glVertex2d(bl.getX(),bl.getY());
			glVertex2d(tl.getX(),tl.getY());
			glEnd();
		}
	
	}

	virtual void handle(float mx, float my){
			points.push_back(new Vec(mx-x, y-my));
	}

};
#endif
