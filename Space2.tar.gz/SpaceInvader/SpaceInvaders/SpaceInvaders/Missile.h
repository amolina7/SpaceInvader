#ifndef Missile_hpp
#define Missile_hpp
#include "glut_window.h"
#include "point_vector.h"
#include "Ship.h"
#include "Config.h"

class Missile : public Ship{
		
	public:
		float m_x, m_y;
		Missile(){
			m_y = get_y();
			std::cout << "m_x: " << m_x << " m_y: " << m_y << std::endl;
			std::cout << "Missile() has been called" << std::endl;
		}
		Missile(float x){
			m_x = x/2;
			m_y = get_y();
			std::cout << "Missile(x): " << m_x << std::endl;
		}

		void draw(){
			PointVector top_edge;
/*
			top_edge = PointVector(x,y);
			glColor3f(0.0, 1.0, 1.0);
			glBegin(GL_LINES);
			glVertex2d(top_edge.get_x()/2, top_edge.get_y() + Missile_Increment_Bot);
			glVertex2d(top_edge.get_x()/2, top_edge.get_y() + Missile_Increment_Top);
*/
			top_edge = PointVector(m_x, m_y);
			glColor3f(0.0, 1.0, 1.0);
			glBegin(GL_LINES);
	//		glVertex2d(m_x/2, m_y + Missile_Increment_Bot);
	//		glVertex2d(m_x/2, m_y + Missile_Increment_Top);
			glVertex2d(m_x, m_y + Missile_Increment_Bot);
			glVertex2d(m_x, m_y + Missile_Increment_Top);
			glEnd();
			std::cout << "m_x/2: " << m_x/2 << " m_y: " << m_y << std::endl;
			Missile_Increment_Top += 0.05;
			Missile_Increment_Bot += 0.05;
			if((m_y + Missile_Increment_Top) >= 1.0){
				//Will clear the vector
		//		clean();
			}
		}
		void move(float increment){
			m_x += increment;
		}
};
#endif
