//
//  point_vector.hpp
//  glutapp
//
//  Created by Tim Kim on 4/11/16.
//

#ifndef point_vector_hpp
#define point_vector_hpp

#include <iostream>

class PointVector
{
private:
    // Points are defined wrt top left
    float x, y, width, height;
    
public:
    // Constructors
    // Default behavior is [0,0]
    PointVector();
    // Given [x,y]
    PointVector(float x_in, float y_in);
    PointVector(float x_in, float y_in, float width_in, float height_in);
    
    // Adding points together
    void add(PointVector point);
    
    // Printing coordinates of point
    void print();
    
    // Getters
    float get_x ();
    float get_y ();
    float get_width ();
    float get_height ();
    // Setters
    void set_x (float x_in);
    void set_y (float y_in);
    void set_width (float width_in);
    void set_height (float height_in);
};



#endif /* point_vector_hpp */
