//
//  Enemy.hpp
//  glutapp
//
//  Created by Tim Kim on 5/3/16.
//  Copyright © 2016 Angelo Kyrilov. All rights reserved.
//

#ifndef Enemy_hpp
#define Enemy_hpp

#include <stdio.h>
#include "Ship.h"
#include "Config.h"

class Enemy : public Ship
{
public:
    Enemy ()
    {
        Ship();
    }
    
    Enemy (float row_num, float col_id, float total_col)
    {
        Ship();
        float x_increment = 2/total_col;
        float y_increment = 2*height;
        
        x = -1 + 0.5*x_increment - 0.5*width + col_id*x_increment;
        y = 1 - row_num*y_increment;
        set_green(1);
    }
    
    void move(float increment)
    {
        /*
        check_if_edge();
        if (at_right_edge)
        {
            set_moving_left();
        }
        else if (at_left_edge)
        {
            set_moving_right();
        }
         */
        Ship::move(increment);
    }
    
    void draw()
    {
        move(INCREMENT);
        Ship::draw();
    }
	
    
};

#endif /* Enemy_hpp */

