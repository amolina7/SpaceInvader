# include "app_window.h"




AppWindow::AppWindow ( const char* label, int x, int y, int w, int h )
          :GlutWindow ( label, x, y, w, h )
{
   _markx = 0;
   _marky = 0;
   addMenuEntry ( "Option 0", evOption0 );
   addMenuEntry ( "Option 1", evOption1 );
    
    player = new Player();
    missile = new Missile();
    // Initialize number of columns
    num_cols = 5;
    for (int i = 0; i < num_cols; ++i) {
        std::vector<Enemy>* enemy_col = new std::vector<Enemy>;
        enemy.push_back(*enemy_col);
        //enemy.assign(i, *enemy_col);
    }
    
    float counter = 0;
    float num_enemy = 0;
    // Initialize number of rows
    num_rows = 5;
    col_id = 0;
    for (std::vector< std::vector<Enemy> >::iterator it = enemy.begin(); it != enemy.end(); ++it) {
        for (float j = 0; j < num_rows; ++j) {
            Enemy* temp_enemy = new Enemy(j, col_id, (float)enemy.size());
            it->push_back(*temp_enemy);
            //num_enemy++;
        }
        col_id++;
        //std::cout << "Column counter: "<< ++counter << std::endl;
    }
    //std::cout << "Total Enemy count: " << num_enemy << std::endl;
    
    // Enemy vectors that will become the columns of the matrix
    
    
    
    // 'enemy' is the matrix that stores the enemies
    // Initializing enemy matrix
    // Iterator i determines number of columns; current total: 5
    /*
    // First loop iterates through all columns of the matrix
    for (std::vector<std::vector<Enemy*>>::iterator i = enemy.begin(); i != enemy.end(); ++i) {
        for (int j = 0; j < 5; ++j) {
            i->push_back(new Enemy());
        }
    }
    */
}

// mouse events are in window coordinates, but your scene is in [0,1]x[0,1],
// so make here the conversion when needed

// All the window inputs are s.t. the [0,0] is the top left corner and max x is to the right
// max y is to the bottom; max range is [0,0] to [0,1]x[0,1]
// conversion changes this from current form to [-1,1]x[-1,1] range where center is origin
// could be useful for parabolic whatever
void AppWindow::windowToScene ( float& x, float &y )
 {
     //std::cout << "AppWindow::windowToScene X: " << x << " & Y: " << y << std::endl;
   x = (2.0f*(x/float(_w))) - 1.0f;
   y = 1.0f - (2.0f*(y/float(_h)));
     //std::cout << "AFTER CONVERSION X: " << x << " & Y: " << y << std::endl << std::endl;
 }

// Called every time there is a window event
void AppWindow::handle ( const Event& e )
 {
   bool rd=true;

   if ( e.type==Keyboard ) 
    switch ( e.key )
    {
        case ' ': // space bar
            std::cout << "########## Checking all values ##########\n";
           //MissleDraw function call 
	    //Maybe store a missle Object and call draw it in the draw function
	    //Make a check whether the missle vector is empty, if it is then you may store a missle object
	    //If not, then don't draw
	    //If there is a collision, then delete the vector and clear it until the space bar is pressed again
		if(m.size() < 1){
			float p_x = player->get_x();
			std::cout << "Puuuuuuuuuuush" << std::endl;
	   //		m.push_back(missile);
			m.push_back(new Missile(p_x));
		}
	    std::cout << m.size() << std::endl;
            std::cout << "_markx value: " << _markx << "\n";
            std::cout << "_marky value: " << _marky << "\n";
            
            break;

	  case 27: // Esc was pressed
	   exit(1);
	}
     
     if (e.type == MouseDown || e.type == Motion) {
         _markx = (float)e.mx;
         _marky = (float)e.my;
         windowToScene(_markx,_marky);
         PointVector mouse_position = PointVector(_markx, _marky);
     }
    
     /*
     if (e.type == MouseUp) {

     }
      */

   if ( e.type==Menu )
    { std::cout<<"Menu Event: "<<e.menuev<<std::endl;
      rd=false; // no need to redraw
    }

   
     const float increment = 0.05f;
     if ( e.type==SpecialKey )
     {
         switch ( e.key )
         {
             case GLUT_KEY_LEFT:
                 player->set_moving_left();
                 player->move(increment);
		 missile->move(increment);
                 break;
             case GLUT_KEY_RIGHT:
                 player->set_moving_right();
                 player->move(increment);
		 missile->move(increment);
                 break;
             case GLUT_KEY_UP:
                 break;
             case GLUT_KEY_DOWN:
                 break;
             default: rd=false; // no redraw
         }
     }
     
     
   if (rd) redraw(); // ask the window to be rendered when possible
}

void AppWindow::resize ( int w, int h )
 {
   // Define that OpenGL should use the whole window for rendering
   glViewport( 0, 0, w, h );
   _w=w; _h=h;
 }


void AppWindow::check()
{
    float col_counter = 0;
    for (std::vector< std::vector<Enemy> >::iterator i = enemy.begin(); i != enemy.end(); ++i) {
        for (std::vector<Enemy>::iterator j = i->begin(); j != i->end(); ++j) {
            
            if (j->get_at_right_edge()) {
                //std::cout << "RIGHT EDGE DETECTED\n";
                for (std::vector< std::vector<Enemy> >::iterator i = enemy.begin(); i != enemy.end(); ++i) {
                    for (std::vector<Enemy>::iterator j = i->begin(); j != i->end(); ++j) {
                        j->set_moving_left();
                        j->set_at_no_edge();
                        j->set_y(j->get_y()-0.1);
                        if (col_counter == (float)enemy.size()-1) {
                            j->set_x(j->get_x()+INCREMENT);
                        }
                    }
                    ++col_counter;
                }
                //break;
                
            } else if (j->get_at_left_edge()){
                col_counter = 0;
                std::cout << "LEFT EDGE DETECTED\n" << col_counter << std::endl;
                for (std::vector< std::vector<Enemy> >::iterator i = enemy.begin(); i != enemy.end(); ++i) {
                    for (std::vector<Enemy>::iterator j = i->begin(); j != i->end(); ++j) {
                        j->set_moving_right();
                        j->set_at_no_edge();
                        j->set_y(j->get_y()-0.1);
                        if (col_counter == 0) {
                            j->set_x(j->get_x()-INCREMENT);
                        }
                    }
                    ++col_counter;
                }
                //break;
            }
        }
    }
}

void AppWindow::update()
{
    
}

// here we will redraw the scene according to the current state of the application.
void AppWindow::draw ()
{
    check();
    update();
   // Clear the rendering window
   glClear ( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );

   // Clear the trasnformation stack
   glMatrixMode( GL_MODELVIEW );
   glLoadIdentity();
    
    player->draw();
    //Without this statement, it will segfault, since when the program starts there is nothing stored in the vector
    //The only time it will store a Missle object in the vector is when you press the space bar
    //Since you don't press the space bar when the game begins, you are just calling NULL
   // if(!(m.empty())){	//empty works, though you only want to shoot one missile at a time	
    if(m.size() > 0){
	for(std::vector<Missile*>::iterator i = m.begin(); i != m.end(); ++i){	
   	 	(*i)->draw();
		if((*i)->m_y >= 1.0){
			std::cout << "DEEEEEEEEEEEELLLLLLLEEEEEEETE" << std::endl;
			m.clear();
		}
		std::cout<< m.size() << std::endl;
	}
    }
    
    // Draw enemies
    
    for (std::vector< std::vector<Enemy> >::iterator i = enemy.begin(); i != enemy.end(); ++i) {
        for (std::vector<Enemy>::iterator j = i->begin(); j != i->end(); ++j) {
            j->draw();
        }
    }
    

    
   // Swap buffers
   glFlush();         // flush the pipeline (usually not necessary)
   glutSwapBuffers(); // we were drawing to the back buffer, now bring it to the front
}

