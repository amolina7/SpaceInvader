//
//  point_vector.cpp
//  glutapp
//
//  Created by Tim Kim on 4/11/16.
//

#include "point_vector.h"

// Default behavior is [0,0]
PointVector::PointVector()
{
    x = 0.0;
    y = 0.0;
    width = 0.0;
    height = 0.0;
}

// Given [x,y]
PointVector::PointVector(float x_in, float y_in)
{
    x = x_in;
    y = y_in;
    width = 0.0;
    height = 0.0;
}

PointVector::PointVector(float x_in, float y_in, float width_in, float height_in)
{
    x = x_in;
    y = y_in;
    width = width_in;
    height = height_in;
}

void PointVector::add(PointVector point)
{
    x = x + point.x;
    y = y + point.y;
    width = width + point.width;
    height = height + point.height;
}

void PointVector::print()
{
    std::cout << "(" << x << ", " << y << ")";
}

// Getters
float PointVector::get_x ()
{
    return x;
}

float PointVector::get_y ()
{
    return y;
}

float PointVector::get_width ()
{
    return width;
}

float PointVector::get_height ()
{
    return height;
}

// Setters
void PointVector::set_x(float x_in)
{
    x = x_in;
}

void PointVector::set_y (float y_in)
{
    y = y_in;
}

void PointVector::set_width (float width_in)
{
    width = width_in;
}

void PointVector::set_height (float height_in)
{
    height = height_in;
}
