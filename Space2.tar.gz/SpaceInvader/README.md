# SpaceInvader
Recreating Space Invader with a few new features.
First we are to use freeglut as a foundation for the game.
