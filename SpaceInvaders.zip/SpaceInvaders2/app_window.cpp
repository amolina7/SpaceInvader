# include "app_window.h"




AppWindow::AppWindow ( const char* label, int x, int y, int w, int h )
          :GlutWindow ( label, x, y, w, h )
{
   _markx = 0;
   _marky = 0;
   addMenuEntry ( "Option 0", evOption0 );
   addMenuEntry ( "Option 1", evOption1 );
    
    player = new Player();
    // Initialize number of columns
    num_cols = 5;
    for (int i = 0; i < num_cols; ++i) {
        std::vector<Enemy>* enemy_col = new std::vector<Enemy>;
        enemy.push_back(*enemy_col);
        //enemy.assign(i, *enemy_col);
    }

    float counter = 0;
    float num_enemy = 0;
    // Initialize number of rows
    num_rows = 5;
    col_id = 0;
    for (std::vector< std::vector<Enemy> >::iterator it = enemy.begin(); it != enemy.end(); ++it) {
        for (float j = 0; j < num_rows; ++j) {
            Enemy* temp_enemy = new Enemy(j, col_id, (float)enemy.size());
            it->push_back(*temp_enemy);
            //num_enemy++;
        }
        col_id++;
        //std::cout << "Column counter: "<< ++counter << std::endl;
    }
    //std::cout << "Total Enemy count: " << num_enemy << std::endl;
    
    // Enemy vectors that will become the columns of the matrix
    
    
    
    // 'enemy' is the matrix that stores the enemies
    // Initializing enemy matrix
    // Iterator i determines number of columns; current total: 5
    /*
    // First loop iterates through all columns of the matrix
    for (std::vector<std::vector<Enemy*>>::iterator i = enemy.begin(); i != enemy.end(); ++i) {
        for (int j = 0; j < 5; ++j) {
            i->push_back(new Enemy());
        }
    }
    */
}

// mouse events are in window coordinates, but your scene is in [0,1]x[0,1],
// so make here the conversion when needed

// All the window inputs are s.t. the [0,0] is the top left corner and max x is to the right
// max y is to the bottom; max range is [0,0] to [0,1]x[0,1]
// conversion changes this from current form to [-1,1]x[-1,1] range where center is origin
// could be useful for parabolic whatever
void AppWindow::windowToScene ( float& x, float &y )
 {
     //std::cout << "AppWindow::windowToScene X: " << x << " & Y: " << y << std::endl;
   x = (2.0f*(x/float(_w))) - 1.0f;
   y = 1.0f - (2.0f*(y/float(_h)));
     //std::cout << "AFTER CONVERSION X: " << x << " & Y: " << y << std::endl << std::endl;
 }

// Called every time there is a window event
void AppWindow::handle ( const Event& e )
 {
   bool rd=true;
   if ( e.type==Keyboard ) 
    switch ( e.key )
    {
        case ' ': // space bar
        {
            //The only time it will store a Missle object in the vector is when you press the space bar
            Missile* temp_missile = new Missile(player->get_x()+player->get_width()*0.5, player->get_y());
			missile.push_back(*temp_missile);
            break;
        }
            
        case 27: // Esc was pressed
        restart();
	}
     
     if (e.type == MouseDown || e.type == Motion) {
         _markx = (float)e.mx;
         _marky = (float)e.my;
         windowToScene(_markx,_marky);
         PointVector mouse_position = PointVector(_markx, _marky);
     }
    
     /*
     if (e.type == MouseUp) {

     }
      */

   if ( e.type==Menu )
    { std::cout<<"Menu Event: "<<e.menuev<<std::endl;
        switch (e.menuev) {
            case evOption0:
                std::cout << "GOTEM\n";
                break;
                
            default:
                break;
        }
      rd=false; // no need to redraw
    }

   
     const float increment = 0.05f;
     if ( e.type==SpecialKey )
     {
         switch ( e.key )
         {
             case GLUT_KEY_LEFT:
                 player->set_moving_left();
                 player->move(increment);
                 break;
             case GLUT_KEY_RIGHT:
                 player->set_moving_right();
                 player->move(increment);
                 break;
             case GLUT_KEY_UP:
             {
                 break;
             }
             case GLUT_KEY_DOWN:
                 enemy_shoot();
                 break;
             default: rd=false; // no redraw
         }
     }
     
     
   if (rd) redraw(); // ask the window to be rendered when possible
}

void AppWindow::restart()
{
    /*
    // Delete all vectors and reinitialize
    for (std::vector< std::vector<Enemy> >::iterator i = enemy.begin(); i != enemy.end(); ++i) {
        for (std::vector<Enemy>::iterator j = i->begin(); j != i->end(); ++j) {
            j->~Enemy();
        }
    }
    for (std::vector<Missile>::iterator i = missile.begin(); i != missile.end(); ++i) {
        i->~Missile();
    }
    for (std::vector<Missile>::iterator i = enemy_missile.begin(); i != enemy_missile.end(); ++i) {
        i->~Missile();
    }
    */
}

void AppWindow::enemy_shoot()
{
    int shooting_col = rand() % enemy.size();
    std::vector<std::vector<Enemy> >::iterator i = enemy.begin();
    std::advance(i, shooting_col);
    std::vector<Enemy>::iterator j = i->begin();
    std::advance(j, i->size()-1);
    Missile* temp_missile = new Missile(j->get_x()+j->get_width()*0.5, j->get_y()-j->get_height());
    enemy_missile.push_back(*temp_missile);
    
}

void AppWindow::resize ( int w, int h )
 {
   // Define that OpenGL should use the whole window for rendering
   glViewport( 0, 0, w, h );
   _w=w; _h=h;
 }


void AppWindow::check()
{
    // Random enemy missile production
    // Take seconds from player object
    
    player->get_time();
    int current_time = player->get_sec();
    
    // Check to see if it's time to shoot
    if((current_time % (TIME_MODULO + 2)) == time_mod)
    {
        //std::cout << "ITS TIME\n";
        enemy_shoot();
        //std::cout << player->get_sec();
        time_mod = rand() % TIME_MODULO;
        //std::cout << "TIME MOD: " << time_mod;
    }
     
     
    // Check to see if missiles have gone past the top edge
   for (std::vector<Missile>::iterator i = missile.begin(); i != missile.end(); ++i)
   {
        i->check_if_edge();
        if (i->get_at_right_edge()) {
            missile.erase(i);
            //std::cout << "Num missiles: " << missile.size() << "\n";
            break;
        }
       
       for (std::vector<std::vector<Enemy> >::iterator j = enemy.begin(); j != enemy.end(); ++j) {
           for (std::vector<Enemy>::iterator k = j->begin(); k != j->end(); ++k) {
               PointVector missile_point = PointVector(i->get_x(), i->get_y());
               if(k->is_point_inside(missile_point))
               {
                   i->set_delete_me();
                   k->set_delete_me();
                   break;
               }
           }
       }
    }
    
    
    for (std::vector<Missile>::iterator i = enemy_missile.begin(); i != enemy_missile.end(); ++i) {
        i->check_if_edge();
        if (i->get_at_right_edge()) {
            enemy_missile.erase(i);
            break;
        }
        
        PointVector enemy_missile_point = PointVector(i->get_x(), i->get_y());
        if (player->is_point_inside(enemy_missile_point)) {
            i->set_delete_me();
            player->set_delete_me();
        }
    }

     
    // Enemy edge detection and move down logic
    float col_counter = 0;
    for (std::vector< std::vector<Enemy> >::iterator i = enemy.begin(); i != enemy.end(); ++i) {
        for (std::vector<Enemy>::iterator j = i->begin(); j != i->end(); ++j) {
            if (j->get_at_right_edge()) {
                //std::cout << "RIGHT EDGE DETECTED\n";
                for (std::vector< std::vector<Enemy> >::iterator i = enemy.begin(); i != enemy.end(); ++i) {
                    for (std::vector<Enemy>::iterator j = i->begin(); j != i->end(); ++j) {
                        j->set_moving_left();
                        j->set_at_no_edge();
                        j->set_y(j->get_y()-0.1);
                        if (col_counter == (float)enemy.size()-1) {
                            j->set_x(j->get_x()+ENEMY_INCREMENT);
                        }
                    }
                    ++col_counter;
                }
                //break;
                
            } else if (j->get_at_left_edge()){
                col_counter = 0;
                //std::cout << "LEFT EDGE DETECTED\n" << col_counter << std::endl;
                for (std::vector< std::vector<Enemy> >::iterator i = enemy.begin(); i != enemy.end(); ++i) {
                    for (std::vector<Enemy>::iterator j = i->begin(); j != i->end(); ++j) {
                        j->set_moving_right();
                        j->set_at_no_edge();
                        j->set_y(j->get_y()-0.1);
                        if (col_counter == 0) {
                            j->set_x(j->get_x()-ENEMY_INCREMENT);
                        }
                    }
                    ++col_counter;
                }
                //break;
            }
        }
    }
}

void AppWindow::update()
{
    for (std::vector<Missile>::iterator i = missile.begin(); i != missile.end(); ++i) {
        if (i->get_delete_me()) {
            missile.erase(i);
            break;
        }
    }
    
    for (std::vector<Missile>::iterator i = enemy_missile.begin(); i != enemy_missile.end(); ++i) {
        if (i->get_delete_me()) {
            enemy_missile.erase(i);
            break;
        }
    }
    
    if (player->get_delete_me()) {
        player->set_red(0);
        player->set_blue(0);
        player->set_green(0);
        std::cout << "\n^&* YOU DIED *&^\n";
    }
    
    for (std::vector< std::vector<Enemy> >::iterator i = enemy.begin(); i != enemy.end(); ++i) {
        for (std::vector<Enemy>::iterator j = i->begin(); j != i->end(); ++j) {
            if(j->get_delete_me())
            {
                i->erase(j);
                break;
            }
        }
    }
    
    for (std::vector<Missile>::iterator i = missile.begin(); i != missile.end(); ++i) {
        i->move(MISSILE_INCREMENT);
    }
    for (std::vector<Missile>::iterator i = enemy_missile.begin(); i != enemy_missile.end(); ++i) {
        i->move(-MISSILE_INCREMENT);
    }
    
}

// here we will redraw the scene according to the current state of the application.
void AppWindow::draw ()
{
    check();
    update();
   // Clear the rendering window
   glClear ( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );

   // Clear the trasnformation stack
   glMatrixMode( GL_MODELVIEW );
   glLoadIdentity();
    
    // Draw player
    player->draw();
    
    // Draw player misisles
    for(std::vector<Missile>::iterator i = missile.begin(); i != missile.end(); ++i)
    {
   	 	(i)->draw();
    }
    
    // Draw enemy missiles
    for (std::vector<Missile>::iterator i = enemy_missile.begin(); i != enemy_missile.end(); ++i) {
        i->draw();
    }
    
    // Draw enemies
    for (std::vector< std::vector<Enemy> >::iterator i = enemy.begin(); i != enemy.end(); ++i) {
        for (std::vector<Enemy>::iterator j = i->begin(); j != i->end(); ++j) {
            j->draw();
        }
    }
    

    
   // Swap buffers
   glFlush();         // flush the pipeline (usually not necessary)
   glutSwapBuffers(); // we were drawing to the back buffer, now bring it to the front
}

