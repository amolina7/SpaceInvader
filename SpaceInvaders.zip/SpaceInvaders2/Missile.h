#ifndef Missile_hpp
#define Missile_hpp
#include "point_vector.h"
#include "Ship.h"
#include "Config.h"

class Missile : public Ship{
protected:
    float missile_width = 0.05;
    
public:
    Missile()
    {
        Ship();
        x = 0.0;
        y = -0.9;
        blue = 1.0;
        green = 1.0;
        
    }
    
    Missile(float x_in, float y_in){
        Ship();
        x = x_in;
        y = y_in;
        blue = 1.0;
        green = 1.0;
        at_right_edge = false;
    }
    
    ~Missile()
    {
        Ship::~Ship();
    }

    void check_if_edge()
    {
        if (y >= 1.0)
        {
            at_right_edge = true;
        }
        else if (y <= -1.0)
        {
            at_right_edge = true;
        }
    }
    
    void draw(){
/*
        top_edge = PointVector(x,y);
        glColor3f(0.0, 1.0, 1.0);
        glBegin(GL_LINES);
        glVertex2d(top_edge.get_x()/2, top_edge.get_y() + Missile_Increment_Bot);
        glVertex2d(top_edge.get_x()/2, top_edge.get_y() + Missile_Increment_Top);
*/
        glColor3f(red, blue, green);
        glBegin(GL_LINES);
////		glVertex2d(m_x/2, m_y + Missile_Increment_Bot);
////		glVertex2d(m_x/2, m_y + Missile_Increment_Top);
        glVertex2d(x, y);
        glVertex2d(x, y + missile_width);
        glEnd();
        }
    void move(float increment)
    {
        y += increment;
    }
};
#endif
