//
//  Config.hpp
//  glutapp
//
//  Created by Tim Kim on 5/5/16.
//  Copyright © 2016 Angelo Kyrilov. All rights reserved.
//

#ifndef Config_hpp
#define Config_hpp

#include <stdio.h>
const float ENEMY_INCREMENT = 0.001;
const float MISSILE_INCREMENT = 0.05;
static float Missile_Increment_Top = 0.05;
static float Missile_Increment_Bot = 0.0;

const int TIME_MODULO = 3;
#endif /* Config_hpp */
