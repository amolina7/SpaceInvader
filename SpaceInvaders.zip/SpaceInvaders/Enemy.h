//
//  Enemy.hpp
//  glutapp
//
//  Created by Tim Kim on 5/3/16.
//  Copyright © 2016 Angelo Kyrilov. All rights reserved.
//

#ifndef Enemy_hpp
#define Enemy_hpp

#include <stdio.h>
#include "Ship.h"

class Enemy : public Ship
{
public:
    Enemy ()
    {
        Ship();
    }
};

#endif /* Enemy_hpp */
