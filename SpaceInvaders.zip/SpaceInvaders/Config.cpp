//
//  Config.cpp
//  glutapp
//
//  Created by Tim Kim on 5/5/16.
//  Copyright © 2016 Angelo Kyrilov. All rights reserved.
//

#include "Config.h"
