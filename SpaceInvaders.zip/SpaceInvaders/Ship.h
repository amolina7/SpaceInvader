//
//  Ship.hpp
//  glutapp
//
//  Created by Tim Kim on 4/11/16.
//  Copyright © 2016 Angelo Kyrilov. All rights reserved.
//

#ifndef Ship_hpp
#define Ship_hpp

#include "glut_window.h"
#include "point_vector.h"
#include <iostream>
#include <vector>
#include <ctime>

class Ship
{
protected:
    float x, y, width, height;
    float red, green, blue;
    float sec;
    bool moving_right, at_right_edge, at_left_edge;
    // Each Ship will have its own vector that stores point objects
    std::vector<PointVector*> point;
public:
    // CONSTRUCTORS
    // Default constructor
    Ship ();
    // Ship defn. without color specified (random)
    Ship (float x_in, float y_in, float width_in, float height_in);
    // Ship defn. with all params specified
    Ship (float x_in, float y_in, float width_in, float height_in, float red_in, float blue_in, float green_in);
    //END: CONSTRUCTORS
    
    bool is_point_inside (PointVector point);
    
    float get_x ();
    float get_y ();
    float get_width ();
    float get_height ();
    float get_drag_buffer ();
    float get_red ();
    float get_blue ();
    float get_green ();
    
    void set_x (float x_in);
    void set_y (float y_in);
    void set_width (float width_in);
    void set_height (float height_in);
    void set_drag_buffer (float drag_buffer_in);
    void set_red (float red_in);
    void set_blue (float blue_in);
    void set_green (float green_in);
    void set_moving_right();
    void set_moving_left();
    
    void check_if_edge();
    
    void get_time();
    void shoot(); //NOT IMPLEMENTED YET
    
    virtual void draw();
    virtual void move(float increment);
    virtual void handle (float x_in, float y_in);
};

#endif /* Ship_hpp */






































