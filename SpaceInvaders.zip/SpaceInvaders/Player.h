//
//  Player.hpp
//  glutapp
//
//  Created by Tim Kim on 5/3/16.
//  Copyright © 2016 Angelo Kyrilov. All rights reserved.
//

#ifndef Player_hpp
#define Player_hpp

#include "Ship.h"

class Player : public Ship
{
    // Implement shooting function (spacebar)
public:
    // Player starts in same place every time game starts over
    Player()
    {
        Ship();
	std::cout << "Ship()" << std::endl;
    }
    
    Player(float x, float y, float w, float h, float r, float g, float b)
    {
        Ship(x,y,w,h,r,g,b);
    }
    
    ~Player()
    {
        Ship::~Ship();
    }
};


#endif /* Player_hpp */
