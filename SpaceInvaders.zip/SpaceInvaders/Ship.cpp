//
//  Ship.cpp
//  glutapp
//
//  Created by Tim Kim on 4/11/16.
//  Copyright © 2016 Angelo Kyrilov. All rights reserved.
//

#include "Ship.h"

// CONSTRUCTORS
// Default constructor
Ship::Ship ()
{
    x = 0.0;
    y = -0.9;
    width = 0.1;
    height = 0.1;
    red = 1.0;
    blue = 0.0;
    green = 0.0;
    moving_right = true;
}

// Ship defn. without color specified (random)
Ship::Ship (float x_in, float y_in, float width_in, float height_in)
{
    x = x_in;
    y = y_in;
    width = width_in;
    height = height_in;
    red = 0.5;
    blue = 0.5;
    green = 0.5;
}

// Ship defn. with all params specified
Ship::Ship (float x_in, float y_in, float width_in, float height_in, float red_in, float blue_in, float green_in)
{
    x = x_in;
    y = y_in;
    width = width_in;
    height = height_in;
    red = red_in;
    blue = blue_in;
    green = green_in;
    moving_right = true;
}
//END: CONSTRUCTORS

bool Ship::is_point_inside (PointVector point)
{
    //std::cout << "ENTERED Ship ISPOINTINSIDE\n";
    /*
    glColor3f(1, 1, 1);
    glBegin(GL_POINTS);
    glVertex2d(point.get_x(), point.get_y());
    glEnd();
    */
    
    if ( ((point.get_x() > x) && (point.get_x() < x + width)) &&
        ((point.get_y() < y) && (point.get_y() > y - height)) )
    {
        //std::cout << "TRUE\n";
        return true;
    }
    else
    {
        //std::cout << "FALSE\n";
        return false;
    }
}

float Ship::get_x ()
{
    return x;
}

float Ship::get_y ()
{
    return y;
}

float Ship::get_width ()
{
    return width;
}

float Ship::get_height ()
{
    return height;
}

float Ship::get_red ()
{
    return red;
}

float Ship::get_blue ()
{
    return blue;
}

float Ship::get_green ()
{
    return green;
}

void Ship::set_x (float x_in)
{
    x = x_in;
}

void Ship::set_y (float y_in)
{
    y = y_in;
}

void Ship::set_width (float width_in)
{
    width = width_in;
}

void Ship::set_height (float height_in)
{
    height = height_in;
}

void Ship::set_red (float red_in)
{
    if (red_in >= 0 && red_in <= 1) {
        red = red_in;
    }
}

void Ship::set_blue (float blue_in)
{
    if (blue_in >= 0 && blue_in <= 1) {
        blue = blue_in;
    }
}

void Ship::set_green (float green_in)
{
    if (green_in >= 0 && green_in <= 1) {
        green = green_in;
    }
}

void Ship::set_moving_right()
{
    moving_right = true;
}
void Ship::set_moving_left()
{
    moving_right = false;
}


void Ship::get_time ()
{
    std::time_t time = std::time(NULL);
    std::tm* tm = std::localtime(&time);
    sec = tm->tm_sec;
}

void Ship::draw()
{
    PointVector top_left, top_right, bot_left, bot_right;
    
    top_left = PointVector (x, y);
    top_right = PointVector (x + width, y);
    bot_left = PointVector (x, y - height);
    bot_right = PointVector (x + width, y - height);
    

    // Draw Ship with color
    glColor3f (red, green, blue);
    glBegin (GL_POLYGON);
    glVertex2d(top_left.get_x(), top_left.get_y());
    glVertex2d(top_right.get_x(), top_right.get_y());
    glVertex2d(bot_right.get_x(), bot_right.get_y());
    glVertex2d(bot_left.get_x(), bot_left.get_y());
    glEnd();
    
    
} //END draw()

void Ship::check_if_edge()
{
    // Left edge of screen
    if (x <= -1.0)
    {
        at_left_edge = true;
    }
    else if ((x >= 1.0-width))
    {
        at_right_edge = true;
    }
}
void Ship::move(float increment)
{
    check_if_edge();
    // Moving right
    if (moving_right)
    {
        if (!at_right_edge)
        {
            x += increment;
            at_left_edge = false;
        }
    }
    // Moving left
    else
    {
        if (!at_left_edge)
        {
            x -= increment;
            at_right_edge = false;
        }
    }
}

void Ship::handle (float x_in, float y_in)
{
    point.push_back(new PointVector(x - x_in, y - y_in));
}





















