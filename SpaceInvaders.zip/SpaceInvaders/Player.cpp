//
//  Player.cpp
//  glutapp
//
//  Created by Tim Kim on 5/3/16.
//  Copyright © 2016 Angelo Kyrilov. All rights reserved.
//

#include "Player.h"
