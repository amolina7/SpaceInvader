//
//  plot_rectangle.cpp
//  glutapp
//
//  Created by Tim Kim on 4/12/16.
//  Copyright © 2016 Angelo Kyrilov. All rights reserved.
//

#include "plot_rectangle.h"
