#ifndef Missile_hpp
#define Missile_hpp
#include "point_vector.h"
#include "Ship.h"
#include "Config.h"

class Missile : public Ship{
protected:
    //float missile_width;
    
public:
    Missile()
    {
        Ship();
        x = 0.0;
        y = -0.9;
        red = 0.0;
        blue = 0.0;
        green = 0.0;
        
    }
    
    Missile(float x_in, float y_in){
        Ship();
        x = x_in;
        y = y_in;
        red = 0.0;
        blue = 0.0;
        green = 0.0;
        at_right_edge = false;
    }
    
    ~Missile()
    {
        Ship::~Ship();
    }

    void check_if_edge()
    {
        if (y >= 1.0)
        {
            at_right_edge = true;
        }
        else if (y <= -1.0)
        {
            at_right_edge = true;
        }
    }
    
    void drawPlayerMissile(){
        
        PointVector top_left, top_right, bot_left, bot_right;
        
        top_left = PointVector (x, y);
        top_right = PointVector (x + width, y);
        bot_left = PointVector (x, y - height);
        bot_right = PointVector (x + width, y - height);
        
        glColor3f(0.9, 0.9, 0.98);
        glBegin(GL_POLYGON);
        glVertex2d(top_left.get_x(), top_left.get_y());
        glVertex2d(top_left.get_x(), top_left.get_y()+0.01);
        glVertex2d(top_left.get_x()+0.01, top_left.get_y()+0.01);
        glVertex2d(top_left.get_x()+0.01, top_left.get_y());
        glEnd();
        
        glColor3f(0.9, 0.9, 0.98);
        glBegin(GL_POLYGON);
        glVertex2d(top_left.get_x()+0.02, top_left.get_y());
        glVertex2d(top_left.get_x()+0.02, top_left.get_y()+0.01);
        glVertex2d(top_left.get_x()+0.03, top_left.get_y()+0.01);
        glVertex2d(top_left.get_x()+0.03, top_left.get_y());
        glEnd();
        
        glColor3f(0.9, 0.9, 0.98);
        glBegin(GL_POLYGON);
        glVertex2d(top_left.get_x()+0.01, top_left.get_y()+0.025);
        glVertex2d(top_left.get_x()+0.01, top_left.get_y()+0.037);
        glVertex2d(top_left.get_x()+0.02, top_left.get_y()+0.025);
        glVertex2d(top_left.get_x()+0.02, top_left.get_y()+0.037);
        glEnd();
        
        glColor3f(0.8, 0.0, 0.0);
        glBegin(GL_POLYGON);
        glVertex2f(x, y);
        glVertex2f(x, y+0.037);
        glVertex2f(x+0.03, y+0.037);
        glVertex2f(x+0.03, y);
        glEnd();
    }
    
    
    void drawEnemyMissile(){
        PointVector top_left, top_right, bot_left, bot_right;
        
        top_left = PointVector (x, y);
        top_right = PointVector (x + width, y);
        bot_left = PointVector (x, y - height);
        bot_right = PointVector (x + width, y - height);
        
        glColor3f(0.9, 0.9, 0.98);
        glBegin(GL_POLYGON);
        glVertex2d(top_left.get_x()+0.02, top_left.get_y()+0.01);
        glVertex2d(top_left.get_x()+0.02, top_left.get_y()+0.02);
        glVertex2d(top_left.get_x()+0.03, top_left.get_y()+0.02);
        glVertex2d(top_left.get_x()+0.03, top_left.get_y()+0.01);
        glEnd();
        
        glColor3f(0.9, 0.9, 0.98);
        glBegin(GL_POLYGON);
        glVertex2d(top_left.get_x(), top_left.get_y()+0.01);
        glVertex2d(top_left.get_x(), top_left.get_y()+0.02);
        glVertex2d(top_left.get_x()+0.01, top_left.get_y()+0.02);
        glVertex2d(top_left.get_x()+0.01, top_left.get_y()+0.01);
        glEnd();
        
        glColor3f(0.9, 0.9, 0.98);
        glBegin(GL_POLYGON);
        glVertex2d(top_left.get_x()+0.01, top_left.get_y()+0.025);
        glVertex2d(top_left.get_x()+0.01, top_left.get_y()+0.037);
        glVertex2d(top_left.get_x()+0.02, top_left.get_y()+0.025);
        glVertex2d(top_left.get_x()+0.02, top_left.get_y()+0.037);
        glEnd();
        
        glColor3f(0.9, 0.9, 0.98);
        glBegin(GL_POLYGON);
        glVertex2d(top_left.get_x()+0.01, top_left.get_y());
        glVertex2d(top_left.get_x()+0.01, top_left.get_y()+0.01);
        glVertex2d(top_left.get_x()+0.02, top_left.get_y());
        glVertex2d(top_left.get_x()+0.02, top_left.get_y()+0.01);
        glEnd();
        
        glColor3f(0.0, 0.0, 0.0);
        glBegin(GL_POLYGON);
        glVertex2f(x, y);
        glVertex2f(x, y+0.037);
        glVertex2f(x+0.03, y+0.037);
        glVertex2f(x+0.03, y);
        glEnd();
    }
    
    void move(float increment)
    {
        y += increment;
    }
};
#endif
