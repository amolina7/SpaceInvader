//
//  plot_rectangle.hpp
//  glutapp
//
//  Created by Tim Kim on 4/12/16.
//  Copyright © 2016 Angelo Kyrilov. All rights reserved.
//

#ifndef plot_rectangle_hpp
#define plot_rectangle_hpp

#include "rectangle.h"

class PlotRectangle : public Rectangle
{
protected:
    // Constants that will be coefficient in front of
    float k1, k2, k3, k4;
    std::vector<PointVector*> plot_point;
public:
    void add (float x_in, float y_in)
    {
        float x_scaled = (x_in + 1)/(2.0)*(width)+x;
        float y_scaled = (-1 + y_in)/(2.0)*(height)+y;
        PointVector *point_in = new PointVector(x_scaled, y_scaled);
        if (is_point_inside(*point_in)) {
            plot_point.push_back(point_in);
        } else {
            delete point_in;
        }
        
        
    }
    // Pure virtual function to be defined by inheriting classes
    virtual void generate (float xini, float xend, float inc) { }
    
    
    void set_k1 (float k1_in)
    {
        k1 = k1_in;
    }
    void set_k2 (float k2_in)
    {
        k2 = k2_in;
    }
    void set_k3 (float k3_in)
    {
        k3 = k3_in;
    }
    void set_k4 (float k4_in)
    {
        k4 = k4_in;
    }
    float get_k1 ()
    {
        return k1;
    }
    float get_k2 ()
    {
        return k2;
    }
    float get_k3 ()
    {
        return k3;
    }
    float get_k4 ()
    {
        return k4;
    }
};

class QuadraticRectangle : public PlotRectangle
{
public:
    // Constructors
    // All params specified
    QuadraticRectangle(float x_in, float y_in, float width_in, float height_in, float red_in, float green_in, float blue_in, float k1_in, float k2_in, float k3_in)
    {
        x = x_in;
        y = y_in;
        width = width_in;
        height = height_in;
        red = red_in;
        blue = blue_in;
        green = green_in;
        k1 = k1_in;
        k2 = k2_in;
        k3 = k3_in;
    }
    
    // -1, 1, 0.1
    void generate (float xini, float xend, float inc)
    {
        plot_point.clear();
        // Over some interval [xini,xend] with inc divisions
        for (float i = xini; i <= xend; i += inc)
        {
            //std::cout << "VALUE i: " << i << "\n";
            // add the x = i, y=k1x^2+k2x+k3 (quadratic)
            add (i, ((k1*i*i)+(k2*i)+k3));
            
        }
    }
    
    void draw_quadratic ()
    {
        PointVector top_left, top_right, bot_left, bot_right;
        
        top_left = PointVector (x, y);
        top_right = PointVector (x + width, y);
        bot_left = PointVector (x, y - height);
        bot_right = PointVector (x + width, y - height);
        
        //Repaint the polygon bar on the top
        glColor3f(red, green, blue);
        glBegin(GL_POLYGON);
        glVertex2f(top_left.get_x(), top_left.get_y());
        glVertex2f(top_right.get_x(), top_left.get_y());
        glVertex2f(top_right.get_x(), top_left.get_y()-drag_buffer);
        glVertex2f(top_left.get_x(), top_left.get_y()-drag_buffer);
        glEnd();
        
        // Hard coded generate from [-1,1]
        // make regenerate function based on arrow keys, dont redraw all the time???
        generate(-0.99, 0.99, 0.01);
        
        glColor3f(1, 1, 1);
        glBegin(GL_POINTS);
        for (std::vector<PointVector*>::iterator i = plot_point.begin(); i != plot_point.end(); i++)
        {
            //std::cout << "SIZE OF plot_point: " << plot_point.size() << "\n";
            glVertex2f((*i)->get_x(), (*i)->get_y());
            //std::cout << (*i)->get_x() << "  " << (*i)->get_y() << "\n";
        }
        glEnd();
        
        
        // Superimpose coordinate axes
        glColor3f(1, 1, 1);
        glBegin(GL_LINES);
        // x-axis
        glVertex2f(x, y-((0.5)*height));
        glVertex2f(x + width, y-((0.5)*height));
        // y-axis
        glVertex2f(x+((0.5)*width), y);
        glVertex2f(x+((0.5)*width), y-height);
        glEnd();
        
        // Draw the rectangles normally
        draw();
        
    }
    
};

class CubicRectangle : public PlotRectangle
{
    
public:
    CubicRectangle(float x_in, float y_in, float width_in, float height_in, float red_in, float green_in, float blue_in, float k1_in, float k2_in, float k3_in, float k4_in)
    {
        x = x_in;
        y = y_in;
        width = width_in;
        height = height_in;
        red = red_in;
        blue = blue_in;
        green = green_in;
        k1 = k1_in;
        k2 = k2_in;
        k3 = k3_in;
        k4 = k4_in;
    }
    
    // -1, 1, 0.1
    void generate (float xini, float xend, float inc)
    {
        plot_point.clear();
        // Over some interval [xini,xend] with inc divisions
        for (float i = xini; i <= xend; i += inc)
        {
            //std::cout << "VALUE i: " << i << "\n";
            // add the x = i, y=k1x^2+k2x+k3 (quadratic)
            add (i, ((k1*i*i*i)+(k2*i*i)+(k3*i))+k4);
            
        }
    }
    
    void draw_cubic ()
    {
        PointVector top_left, top_right, bot_left, bot_right;
        
        top_left = PointVector (x, y);
        top_right = PointVector (x + width, y);
        bot_left = PointVector (x, y - height);
        bot_right = PointVector (x + width, y - height);
        
        //Repaint the polygon bar on the top
        glColor3f(red, green, blue);
        glBegin(GL_POLYGON);
        glVertex2f(top_left.get_x(), top_left.get_y());
        glVertex2f(top_right.get_x(), top_left.get_y());
        glVertex2f(top_right.get_x(), top_left.get_y()-drag_buffer);
        glVertex2f(top_left.get_x(), top_left.get_y()-drag_buffer);
        glEnd();
        
        // Hard coded generate from [-1,1]
        // make regenerate function based on arrow keys, dont redraw all the time???
        generate(-0.99, 0.99, 0.01);
        
        glColor3f(1, 1, 1);
        glBegin(GL_POINTS);
        for (std::vector<PointVector*>::iterator i = plot_point.begin(); i != plot_point.end(); i++)
        {
            //std::cout << "SIZE OF plot_point: " << plot_point.size() << "\n";
            glVertex2f((*i)->get_x(), (*i)->get_y());
            //std::cout << (*i)->get_x() << "  " << (*i)->get_y() << "\n";
        }
        glEnd();
        
        
        // Superimpose coordinate axes
        glColor3f(1, 1, 1);
        glBegin(GL_LINES);
        // x-axis
        glVertex2f(x, y-((0.5)*height));
        glVertex2f(x + width, y-((0.5)*height));
        // y-axis
        glVertex2f(x+((0.5)*width), y);
        glVertex2f(x+((0.5)*width), y-height);
        glEnd();
        
        // Draw the rectangles normally
        draw();
        
    }

};




#endif /* plot_rectangle_hpp */
