
// Ensure the header file is included only once in multi-file projects
#ifndef APP_WINDOW_H
#define APP_WINDOW_H

#include "Ship.h"
#include "Player.h"
#include "Enemy.h"
#include "Config.h"

//#include "plot_rectangle.h"
#include "glut_window.h"
#include <iostream>
#include <vector>

// The functionality of your application should be implemented inside AppWindow
class AppWindow : public GlutWindow
 { private :
    enum MenuEv { evOption0, evOption1 };
    float _markx, _marky;
    int _w, _h;

     float num_cols, num_rows, col_id;
     Player* player;
     std::vector< std::vector<Enemy> > enemy; //= std::vector<std::vector<Enemy> >(5);
     
     bool mouse_dragging;
     bool mouse_down;
     bool is_resizing;
   public :
    AppWindow ( const char* label, int x, int y, int w, int h );
    void windowToScene ( float& x, float &y );
     
     float x_offset, y_offset;
     float x_anchor, y_anchor;
     
     

   private : // functions derived from the base class
    virtual void handle ( const Event& e );
    virtual void draw ();
    virtual void resize ( int w, int h );
     void update();
     void check();
 };

#endif // APP_WINDOW_H
